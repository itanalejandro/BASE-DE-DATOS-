<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['usuario'])) {
    echo json_encode([]);
    exit();
}

include '../conexion.php';

$id_cliente = $_SESSION['id'];

$result = $conn->query("SELECT v.*, p.Nombre as producto FROM Ventas v JOIN Productos p ON v.Id_producto = p.Id_producto WHERE v.Id_cliente = $id_cliente ORDER BY v.Fecha DESC");

$pedidos = [];
while ($row = $result->fetch_assoc()) {
    $pedidos[] = [
        'id' => $row['Id_venta'],
        'fecha' => $row['Fecha'],
        'total' => $row['Total'],
        'estatus' => 'Completado',
        'items' => [['nombre' => $row['producto'], 'precio' => $row['Total']]]
    ];
}

echo json_encode($pedidos);
?>