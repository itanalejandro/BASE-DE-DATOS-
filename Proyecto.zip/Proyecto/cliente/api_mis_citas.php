<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['usuario'])) {
    echo json_encode([]);
    exit();
}

include '../conexion.php';

$id_cliente = $_SESSION['id'];

$result = $conn->query("SELECT c.*, s.Descripcion as servicio FROM Citas c JOIN Servicio_reparacion s ON c.Id_servicio = s.Id_servicio WHERE c.Id_cliente = $id_cliente ORDER BY c.Fecha DESC");

$citas = [];
while ($row = $result->fetch_assoc()) {
    $citas[] = $row;
}

echo json_encode($citas);
?>