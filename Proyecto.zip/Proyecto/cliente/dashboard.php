<?php
session_start();

if (!isset($_SESSION['usuario'])) {
    header("Location: ../login.html");
    exit();
}

include '../conexion.php';

$id_cliente = $_SESSION['id'];
$mensaje = '';
$tipo_mensaje = '';

// ========== AGENDAR CITA ==========
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['agendar_cita'])) {
    $id_servicio = $_POST['id_servicio'];
    $fecha = $_POST['fecha'];
    $hora = $_POST['hora'];
    $descripcion = $_POST['descripcion'] ?? '';
    
    $stmt = $conn->prepare("INSERT INTO Citas (Id_cliente, Id_servicio, Fecha, Hora, Descripcion, Estado) VALUES (?, ?, ?, ?, ?, 'Programada')");
    $stmt->bind_param("iisss", $id_cliente, $id_servicio, $fecha, $hora, $descripcion);
    
    if ($stmt->execute()) {
        $mensaje = "✅ Cita agendada correctamente";
        $tipo_mensaje = "exito";
    } else {
        $mensaje = "❌ Error: " . $stmt->error;
        $tipo_mensaje = "error";
    }
}

// ========== COMPRAR PRODUCTO ==========
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['comprar'])) {
    $id_producto = $_POST['id_producto'];
    $cantidad = $_POST['cantidad'] ?? 1;
    $direccion = $_POST['direccion'] ?? 'Sin dirección';
    
    // Obtener precio del producto
    $prod = $conn->query("SELECT Precio, Stock FROM Productos WHERE Id_producto = $id_producto")->fetch_assoc();
    
    if ($prod['Stock'] >= $cantidad) {
        $total = $prod['Precio'] * $cantidad;
        $fecha = date('Y-m-d');
        
        $stmt = $conn->prepare("INSERT INTO Ventas (Fecha, Total, Direccion, Id_cliente, Id_usuario, Id_producto) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sdssii", $fecha, $total, $direccion, $id_cliente, $id_cliente, $id_producto);
        
        if ($stmt->execute()) {
            // Actualizar stock
            $nuevo_stock = $prod['Stock'] - $cantidad;
            $conn->query("UPDATE Productos SET Stock = $nuevo_stock WHERE Id_producto = $id_producto");
            $mensaje = "✅ Compra realizada exitosamente. Total: $$total";
            $tipo_mensaje = "exito";
        } else {
            $mensaje = "❌ Error al procesar compra";
            $tipo_mensaje = "error";
        }
    } else {
        $mensaje = "❌ Stock insuficiente. Disponible: " . $prod['Stock'];
        $tipo_mensaje = "error";
    }
}

// ========== OBTENER DATOS ==========
$servicios = $conn->query("SELECT Id_servicio, Descripcion, Costo FROM Servicio_reparacion WHERE Estado = 'Activo'");
$productos = $conn->query("SELECT * FROM Productos WHERE Stock > 0 ORDER BY Nombre");
$citas = $conn->query("SELECT c.*, s.Descripcion as servicio FROM Citas c JOIN Servicio_reparacion s ON c.Id_servicio = s.Id_servicio WHERE c.Id_cliente = $id_cliente ORDER BY c.Fecha DESC");
$ordenes = $conn->query("SELECT o.*, s.Descripcion as servicio FROM Ordenes_reparacion o JOIN Servicio_reparacion s ON o.Id_servicio = s.Id_servicio WHERE o.Id_cliente = $id_cliente ORDER BY o.Id_orden DESC");
$ventas = $conn->query("SELECT v.*, p.Nombre as producto FROM Ventas v JOIN Productos p ON v.Id_producto = p.Id_producto WHERE v.Id_cliente = $id_cliente ORDER BY v.Fecha DESC");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>CellRepair - Mi Cuenta</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        *{margin:0;padding:0;box-sizing:border-box;}
        body{font-family:'Inter',sans-serif;background:#f0f2f5;}
        
        /* Header */
        .header{background:linear-gradient(135deg,#1e2a3a,#0f1724);color:#fff;padding:15px 30px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;}
        .logo{font-size:1.5rem;font-weight:700;}
        .logo i{color:#4facfe;}
        .user-info{display:flex;align-items:center;gap:15px;}
        .user-name{background:rgba(255,255,255,0.2);padding:8px 15px;border-radius:30px;}
        .logout{background:#ff6b6b;color:#fff;padding:8px 20px;border-radius:30px;text-decoration:none;}
        
        /* Navegación */
        .nav-tabs{background:#fff;padding:0 30px;display:flex;gap:30px;border-bottom:2px solid #e0e0e0;flex-wrap:wrap;}
        .tab-btn{background:none;border:none;padding:15px 0;font-size:1rem;font-weight:600;cursor:pointer;color:#666;transition:0.3s;}
        .tab-btn.active{color:#4facfe;border-bottom:3px solid #4facfe;}
        
        /* Contenido */
        .tab-content{display:none;padding:30px;}
        .tab-content.active{display:block;}
        
        /* Tarjetas */
        .card{background:#fff;border-radius:20px;padding:25px;margin-bottom:25px;box-shadow:0 5px 15px rgba(0,0,0,0.05);}
        .card h2{margin-bottom:20px;color:#1e2a3a;border-left:4px solid #4facfe;padding-left:15px;}
        
        /* Productos */
        .productos-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:20px;}
        .producto-card{background:#f8f9fa;border-radius:15px;padding:20px;text-align:center;transition:transform 0.3s;}
        .producto-card:hover{transform:translateY(-5px);}
        .producto-card i{font-size:3rem;color:#4facfe;}
        .producto-card h4{margin:10px 0;color:#1e2a3a;}
        .producto-card .precio{color:#003366;font-weight:bold;font-size:1.2rem;}
        .producto-card .stock{font-size:0.8rem;color:#666;margin:5px 0;}
        .btn-compra{background:#4facfe;color:#fff;border:none;padding:8px 20px;border-radius:30px;cursor:pointer;margin-top:10px;width:100%;}
        .btn-compra:hover{background:#003366;}
        
        /* Formulario */
        .form-group{margin-bottom:15px;}
        label{display:block;margin-bottom:5px;font-weight:500;color:#555;}
        input,select,textarea{width:100%;padding:10px;border:1px solid #ddd;border-radius:10px;}
        .btn-primary{background:linear-gradient(135deg,#003366,#4facfe);color:#fff;border:none;padding:12px;border-radius:10px;cursor:pointer;width:100%;font-weight:600;}
        
        /* Listas */
        .lista-item{background:#f8f9fa;border-radius:12px;padding:15px;margin-bottom:10px;border-left:4px solid #4facfe;}
        .lista-titulo{font-weight:bold;color:#003366;}
        .lista-detalle{color:#666;font-size:0.85rem;margin:5px 0;}
        .estado{display:inline-block;padding:3px 12px;border-radius:20px;font-size:0.75rem;}
        .estado-Programada{background:#fff3cd;color:#856404;}
        .estado-Completada{background:#d4edda;color:#155724;}
        .estado-En-proceso{background:#cce5ff;color:#004085;}
        
        .mensaje{padding:12px;border-radius:10px;margin-bottom:20px;text-align:center;}
        .exito{background:#d4edda;color:#155724;}
        .error{background:#f8d7da;color:#721c24;}
        .empty{text-align:center;padding:40px;color:#999;}
        
        @media(max-width:768px){
            .header{flex-direction:column;text-align:center;}
            .nav-tabs{justify-content:center;}
            .tab-content{padding:20px;}
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo"><i class="fas fa-mobile-alt"></i> CellRepair</div>
        <div class="user-info">
            <span class="user-name"><i class="fas fa-user"></i> <?php echo htmlspecialchars($_SESSION['usuario']); ?></span>
            <a href="../logout.php" class="logout"><i class="fas fa-sign-out-alt"></i> Salir</a>
        </div>
    </div>
    
    <div class="nav-tabs">
        <button class="tab-btn active" data-tab="tienda">🛒 Tienda</button>
        <button class="tab-btn" data-tab="citas">📅 Agendar Cita</button>
        <button class="tab-btn" data-tab="mis-citas">📋 Mis Citas</button>
        <button class="tab-btn" data-tab="ordenes">🔧 Órdenes</button>
        <button class="tab-btn" data-tab="compras">💰 Mis Compras</button>
    </div>
    
    <div class="tab-content active" id="tab-tienda">
        <div class="card">
            <h2><i class="fas fa-store"></i> Productos Disponibles</h2>
            <div class="productos-grid">
                <?php while($p = $productos->fetch_assoc()): ?>
                    <div class="producto-card">
                        <i class="fas fa-mobile-alt"></i>
                        <h4><?php echo htmlspecialchars($p['Nombre']); ?></h4>
                        <p class="precio">$<?php echo number_format($p['Precio'], 2); ?></p>
                        <p class="stock"><i class="fas fa-box"></i> Stock: <?php echo $p['Stock']; ?></p>
                        <form method="POST" style="margin-top:10px;">
                            <input type="hidden" name="id_producto" value="<?php echo $p['Id_producto']; ?>">
                            <input type="number" name="cantidad" value="1" min="1" max="<?php echo $p['Stock']; ?>" style="width:80px; padding:5px; margin-bottom:10px;">
                            <input type="text" name="direccion" placeholder="Dirección de envío" required style="margin-bottom:10px;">
                            <button type="submit" name="comprar" class="btn-compra">Comprar Ahora</button>
                        </form>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
    </div>
    
    <div class="tab-content" id="tab-citas">
        <div class="card">
            <h2><i class="fas fa-calendar-plus"></i> Agendar Nueva Cita</h2>
            <?php if($mensaje && $_POST['agendar_cita'] ?? false): ?>
                <div class="mensaje <?php echo $tipo_mensaje; ?>"><?php echo $mensaje; ?></div>
            <?php endif; ?>
            <form method="POST">
                <div class="form-group">
                    <label>Servicio</label>
                    <select name="id_servicio" required>
                        <option value="">Seleccione un servicio</option>
                        <?php while($s = $servicios->fetch_assoc()): ?>
                            <option value="<?php echo $s['Id_servicio']; ?>"><?php echo $s['Descripcion']; ?> - $<?php echo number_format($s['Costo'], 2); ?></option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Fecha</label>
                    <input type="date" name="fecha" required min="<?php echo date('Y-m-d'); ?>">
                </div>
                <div class="form-group">
                    <label>Hora</label>
                    <select name="hora" required>
                        <option value="09:00:00">09:00 AM</option>
                        <option value="10:00:00">10:00 AM</option>
                        <option value="11:00:00">11:00 AM</option>
                        <option value="12:00:00">12:00 PM</option>
                        <option value="13:00:00">01:00 PM</option>
                        <option value="14:00:00">02:00 PM</option>
                        <option value="15:00:00">03:00 PM</option>
                        <option value="16:00:00">04:00 PM</option>
                        <option value="17:00:00">05:00 PM</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Descripción</label>
                    <textarea name="descripcion" rows="3" placeholder="Describe el problema de tu equipo..."></textarea>
                </div>
                <button type="submit" name="agendar_cita" class="btn-primary">Agendar Cita</button>
            </form>
        </div>
    </div>
    
    <div class="tab-content" id="tab-mis-citas">
        <div class="card">
            <h2><i class="fas fa-calendar-alt"></i> Mis Citas</h2>
            <?php if($citas->num_rows == 0): ?>
                <div class="empty"><i class="fas fa-calendar-times"></i><p>No tienes citas agendadas</p></div>
            <?php else: ?>
                <?php while($c = $citas->fetch_assoc()): ?>
                    <div class="lista-item">
                        <div class="lista-titulo"><?php echo htmlspecialchars($c['servicio']); ?></div>
                        <div class="lista-detalle"><i class="fas fa-calendar-day"></i> <?php echo $c['Fecha']; ?> - <i class="fas fa-clock"></i> <?php echo substr($c['Hora'], 0, 5); ?></div>
                        <div class="lista-detalle"><i class="fas fa-file-alt"></i> <?php echo htmlspecialchars($c['Descripcion'] ?: 'Sin descripción'); ?></div>
                        <span class="estado estado-<?php echo $c['Estado']; ?>"><?php echo $c['Estado']; ?></span>
                    </div>
                <?php endwhile; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="tab-content" id="tab-ordenes">
        <div class="card">
            <h2><i class="fas fa-clipboard-list"></i> Mis Órdenes de Reparación</h2>
            <?php if($ordenes->num_rows == 0): ?>
                <div class="empty"><i class="fas fa-folder-open"></i><p>No tienes órdenes de reparación</p></div>
            <?php else: ?>
                <?php while($o = $ordenes->fetch_assoc()): ?>
                    <div class="lista-item">
                        <div class="lista-titulo">Orden #<?php echo $o['Id_orden']; ?> - <?php echo htmlspecialchars($o['servicio']); ?></div>
                        <div class="lista-detalle"><i class="fas fa-stethoscope"></i> Diagnóstico: <?php echo htmlspecialchars($o['Diagnostico'] ?: 'Pendiente'); ?></div>
                        <div class="lista-detalle"><i class="fas fa-dollar-sign"></i> Costo: $<?php echo number_format($o['Costo_final'], 2); ?></div>
                        <span class="estado estado-<?php echo str_replace(' ', '', $o['Estado']); ?>"><?php echo $o['Estado']; ?></span>
                    </div>
                <?php endwhile; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="tab-content" id="tab-compras">
        <div class="card">
            <h2><i class="fas fa-shopping-cart"></i> Mis Compras</h2>
            <?php if($ventas->num_rows == 0): ?>
                <div class="empty"><i class="fas fa-shopping-bag"></i><p>No has realizado compras aún</p></div>
            <?php else: ?>
                <?php while($v = $ventas->fetch_assoc()): ?>
                    <div class="lista-item">
                        <div class="lista-titulo">Compra #<?php echo $v['Id_venta']; ?> - <?php echo htmlspecialchars($v['producto']); ?></div>
                        <div class="lista-detalle"><i class="fas fa-calendar-day"></i> Fecha: <?php echo $v['Fecha']; ?></div>
                        <div class="lista-detalle"><i class="fas fa-map-marker-alt"></i> Dirección: <?php echo htmlspecialchars($v['Direccion'] ?: 'No especificada'); ?></div>
                        <div class="lista-titulo" style="margin-top:5px;">Total: $<?php echo number_format($v['Total'], 2); ?></div>
                    </div>
                <?php endwhile; ?>
            <?php endif; ?>
        </div>
    </div>
    
    <script>
        document.querySelectorAll('.tab-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
                document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
                btn.classList.add('active');
                document.getElementById('tab-' + btn.dataset.tab).classList.add('active');
            });
        });
        
        // Mostrar mensaje si hay éxito/error
        <?php if($mensaje && ($_POST['agendar_cita'] ?? false)): ?>
            document.querySelector('[data-tab="citas"]').click();
        <?php elseif($mensaje && ($_POST['comprar'] ?? false)): ?>
            document.querySelector('[data-tab="compras"]').click();
        <?php endif; ?>
    </script>
</body>
</html>