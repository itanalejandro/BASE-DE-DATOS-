<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['usuario'])) {
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit();
}

include '../conexion.php';

$data = json_decode(file_get_contents('php://input'), true);

$id_cliente = $_SESSION['id'];
$id_servicio = $data['id_servicio'];
$fecha = $data['fecha'];
$hora = $data['hora'];
$descripcion = $data['descripcion'] ?? '';

$stmt = $conn->prepare("INSERT INTO Citas (Id_cliente, Id_servicio, Fecha, Hora, Descripcion, Estado) VALUES (?, ?, ?, ?, ?, 'Programada')");
$stmt->bind_param("iisss", $id_cliente, $id_servicio, $fecha, $hora, $descripcion);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Cita agendada']);
} else {
    echo json_encode(['success' => false, 'message' => $stmt->error]);
}
?>