<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['usuario'])) {
    echo json_encode(['success' => false, 'message' => 'No autorizado']);
    exit();
}

include '../conexion.php';

$data = json_decode(file_get_contents('php://input'), true);
$items = $data['items'];
$total = $data['total'];
$direccion = $data['direccion'] ?? '';

$id_cliente = $_SESSION['id'];
$fecha = date('Y-m-d');

foreach ($items as $item) {
    $id_producto = $item['Id_producto'];
    $stmt = $conn->prepare("INSERT INTO Ventas (Fecha, Total, Direccion, Id_cliente, Id_usuario, Id_producto) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sdssii", $fecha, $total, $direccion, $id_cliente, $id_cliente, $id_producto);
    $stmt->execute();
}

echo json_encode(['success' => true, 'message' => 'Venta registrada']);
?>