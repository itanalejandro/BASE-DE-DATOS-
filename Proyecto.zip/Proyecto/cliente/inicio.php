<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CellRepair - Cliente</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background-color: #f5f5f5; display: block; }
        
        .dashboard-header { background-color: white; box-shadow: 0 2px 10px rgba(0,0,0,0.05); position: sticky; top: 0; z-index: 100; }
        .header-container { max-width: 1400px; margin: 0 auto; padding: 15px 40px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 20px; }
        .logo { font-size: 1.8rem; font-weight: 700; color: #003366; text-decoration: none; }
        .logo i { color: #4facfe; margin-right: 8px; }
        .main-nav { display: flex; gap: 30px; background-color: #f8f9fa; padding: 8px 20px; border-radius: 50px; }
        .nav-link { color: #555; text-decoration: none; font-weight: 500; transition: all 0.3s; display: flex; align-items: center; gap: 8px; padding: 8px 16px; border-radius: 30px; cursor: pointer; }
        .nav-link:hover, .nav-link.active { color: #003366; background-color: #b3e0ff; }
        .header-actions { display: flex; align-items: center; gap: 20px; }
        .search-box { position: relative; }
        .search-box input { padding: 10px 35px 10px 15px; border: 1px solid #ddd; border-radius: 30px; outline: none; width: 200px; transition: all 0.3s; }
        .search-box input:focus { border-color: #b3e0ff; width: 250px; }
        .search-box i { position: absolute; right: 12px; top: 50%; transform: translateY(-50%); color: #999; }
        .cart-icon { position: relative; color: #555; font-size: 1.5rem; text-decoration: none; cursor: pointer; }
        .cart-count { position: absolute; top: -8px; right: -12px; background-color: #003366; color: white; font-size: 0.7rem; padding: 2px 6px; border-radius: 10px; }
        .user-menu { position: relative; }
        .user-icon { color: #555; font-size: 1.8rem; text-decoration: none; cursor: pointer; }
        .user-dropdown { position: absolute; top: 45px; right: 0; background-color: white; border-radius: 12px; box-shadow: 0 10px 30px rgba(0,0,0,0.1); width: 220px; padding: 15px; display: none; z-index: 200; }
        .user-dropdown.show { display: block; }
        .user-dropdown hr { margin: 10px 0; border-color: #eee; }
        .user-dropdown a { display: flex; align-items: center; gap: 10px; padding: 8px 0; color: #555; text-decoration: none; cursor: pointer; }
        .user-dropdown a:hover { color: #003366; }
        .user-info { text-align: center; margin-bottom: 10px; }
        .user-info strong { display: block; color: #003366; }
        .user-info span { font-size: 0.8rem; color: #888; }
        
        .dashboard-main { max-width: 1400px; margin: 0 auto; padding: 30px 40px; }
        .content-section { display: none; }
        .content-section.active { display: block; }
        .section-title { font-size: 2rem; color: #003366; margin-bottom: 30px; border-left: 4px solid #4facfe; padding-left: 15px; }
        .filters-container { display: flex; gap: 15px; margin-bottom: 40px; flex-wrap: wrap; justify-content: center; }
        .filter-btn { background-color: white; border: 2px solid #b3e0ff; padding: 10px 24px; border-radius: 40px; font-size: 1rem; font-weight: 600; color: #003366; cursor: pointer; transition: all 0.3s; display: inline-flex; align-items: center; gap: 8px; }
        .filter-btn:hover, .filter-btn.active { background-color: #003366; color: white; border-color: #003366; }
        .products-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 25px; }
        .product-card { background-color: white; border-radius: 20px; overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.05); transition: transform 0.3s; text-align: center; padding: 20px; cursor: pointer; }
        .product-card:hover { transform: translateY(-5px); box-shadow: 0 15px 30px rgba(0,0,0,0.1); }
        .product-image { background-color: #f8f8f8; border-radius: 15px; padding: 30px 20px; margin-bottom: 15px; min-height: 180px; display: flex; align-items: center; justify-content: center; }
        .product-image img { max-width: 100%; max-height: 140px; object-fit: contain; }
        .product-name { font-size: 1rem; font-weight: 600; color: #333; margin-bottom: 5px; }
        .product-specs { font-size: 0.75rem; color: #777; margin-bottom: 8px; }
        .product-price { font-size: 1.2rem; font-weight: bold; color: #003366; margin-bottom: 12px; }
        .btn-add-cart { background-color: #b3e0ff; color: #003366; border: none; width: 40px; height: 40px; border-radius: 50%; font-size: 1rem; cursor: pointer; transition: all 0.3s; display: flex; align-items: center; justify-content: center; margin: 0 auto; }
        .btn-add-cart:hover { background-color: #99d1ff; transform: scale(1.05); }
        
        .repair-hero { background: linear-gradient(135deg, #003366 0%, #4facfe 100%); border-radius: 30px; padding: 50px 40px; margin-bottom: 40px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; color: white; box-shadow: 0 10px 30px rgba(0,51,102,0.2); }
        .repair-hero-content h3 { font-size: 2rem; margin-bottom: 15px; }
        .repair-hero-content p { opacity: 0.9; margin-bottom: 25px; }
        .repair-stats { display: flex; gap: 40px; flex-wrap: wrap; }
        .stat { text-align: center; }
        .stat-number { display: block; font-size: 2rem; font-weight: bold; }
        .stat-label { font-size: 0.8rem; opacity: 0.8; }
        .repair-hero-icon { font-size: 6rem; opacity: 0.8; }
        
        .services-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 20px; margin-bottom: 40px; }
        .service-card { background: white; border-radius: 20px; padding: 20px; text-align: center; cursor: pointer; transition: transform 0.3s; border: 2px solid transparent; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .service-card.selected { border-color: #4facfe; background: #f0f9ff; }
        .service-card:hover { transform: translateY(-5px); }
        .service-icon { font-size: 2.5rem; color: #4facfe; margin-bottom: 15px; }
        .service-price { font-size: 1.1rem; font-weight: bold; color: #003366; margin-top: 10px; }
        .appointment-section { background: white; border-radius: 25px; padding: 30px; margin-bottom: 40px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        .repair-form .form-group { margin-bottom: 15px; }
        .repair-form label { display: block; margin-bottom: 8px; font-weight: 600; color: #003366; }
        .repair-form input, .repair-form select, .repair-form textarea { width: 100%; padding: 12px 15px; border: 2px solid #e0e0e0; border-radius: 12px; transition: all 0.3s; }
        .repair-form input:focus, .repair-form select:focus, .repair-form textarea:focus { border-color: #4facfe; outline: none; }
        .btn-primary { background: linear-gradient(135deg, #003366 0%, #4facfe 100%); color: white; border: none; padding: 14px 28px; border-radius: 50px; font-size: 1rem; font-weight: 600; cursor: pointer; transition: all 0.3s; width: 100%; }
        .btn-primary:hover { transform: translateY(-2px); box-shadow: 0 5px 15px rgba(0,51,102,0.3); }
        .appointment-item { background: #f9f9f9; padding: 15px; border-radius: 12px; margin-bottom: 10px; border-left: 4px solid #4facfe; }
        
        .orders-container { display: flex; flex-direction: column; gap: 20px; }
        .order-card { background: white; border-radius: 20px; padding: 20px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); border-left: 4px solid #4facfe; transition: transform 0.2s; }
        .order-card:hover { transform: translateX(5px); }
        .order-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; padding-bottom: 10px; border-bottom: 1px solid #eee; flex-wrap: wrap; gap: 10px; }
        .order-id { font-weight: bold; color: #003366; font-size: 1rem; }
        .order-id i { margin-right: 5px; }
        .order-date { color: #666; font-size: 0.85rem; }
        .order-date i { margin-right: 5px; }
        .order-status { background: #d4edda; color: #155724; padding: 4px 12px; border-radius: 20px; font-size: 0.8rem; font-weight: 500; }
        .order-status i { margin-right: 5px; }
        .order-items { margin: 15px 0; }
        .order-item { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #f0f0f0; }
        .order-item-name { color: #333; }
        .order-item-price { font-weight: 500; color: #003366; }
        .order-total { text-align: right; font-size: 1.1rem; font-weight: bold; color: #003366; margin-top: 10px; padding-top: 10px; border-top: 2px solid #eee; }
        .order-total i { margin-right: 8px; }
        .empty-orders { text-align: center; padding: 60px; background: white; border-radius: 20px; color: #999; }
        .empty-orders i { font-size: 4rem; margin-bottom: 15px; color: #ccc; }
        .loading { text-align: center; padding: 40px; color: #666; }
        
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.6); align-items: center; justify-content: center; z-index: 1000; backdrop-filter: blur(3px); }
        .modal.show { display: flex; }
        .modal-content { background: white; border-radius: 30px; max-width: 700px; width: 95%; padding: 30px; position: relative; max-height: 90vh; overflow-y: auto; box-shadow: 0 25px 50px rgba(0,0,0,0.3); }
        .modal-content.large { max-width: 900px; }
        .close-modal { position: absolute; right: 20px; top: 20px; font-size: 1.5rem; cursor: pointer; color: #999; z-index: 10; background: white; width: 35px; height: 35px; border-radius: 50%; display: flex; align-items: center; justify-content: center; transition: all 0.3s; }
        .close-modal:hover { background: #ff6b6b; color: white; transform: rotate(90deg); }
        
        .cart-modal-content { padding: 0; overflow: hidden; }
        .cart-header { background: linear-gradient(135deg, #003366, #4facfe); padding: 20px 25px; color: white; display: flex; align-items: center; gap: 12px; }
        .cart-header i { font-size: 1.8rem; }
        .cart-header h3 { font-size: 1.5rem; margin: 0; }
        .cart-items-list { max-height: 400px; overflow-y: auto; padding: 10px 20px; }
        .cart-item { display: flex; gap: 15px; padding: 15px 0; border-bottom: 1px solid #f0f0f0; align-items: center; transition: all 0.3s; }
        .cart-item:hover { background: #fafafa; }
        .cart-item-img { width: 70px; height: 70px; object-fit: contain; background: #f8f8f8; border-radius: 15px; padding: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); }
        .cart-item-info { flex: 1; }
        .cart-item-info h4 { font-size: 1rem; font-weight: 600; color: #1e2a3a; margin-bottom: 5px; }
        .cart-item-info p { font-size: 0.75rem; color: #777; margin-bottom: 5px; }
        .cart-item-price { font-weight: 700; color: #003366; font-size: 0.9rem; }
        .cart-item-remove { background: none; border: none; color: #ccc; cursor: pointer; font-size: 1.2rem; padding: 8px; border-radius: 50%; transition: all 0.3s; width: 35px; height: 35px; display: flex; align-items: center; justify-content: center; }
        .cart-item-remove:hover { color: #ff6b6b; background: #fff0f0; transform: scale(1.1); }
        .cart-footer { background: #f8f9fa; padding: 20px 25px; border-top: 1px solid #eee; }
        .cart-total { text-align: right; margin-bottom: 15px; }
        .cart-total span { font-size: 1.2rem; color: #666; }
        .cart-total strong { font-size: 1.5rem; color: #003366; margin-left: 10px; }
        .empty-cart { text-align: center; padding: 50px 20px; color: #999; }
        .empty-cart i { font-size: 4rem; margin-bottom: 15px; color: #ccc; }
        
        .checkout-modal-content { padding: 0; overflow: hidden; }
        .checkout-header { background: linear-gradient(135deg, #003366, #4facfe); padding: 20px 25px; color: white; display: flex; align-items: center; gap: 12px; }
        .checkout-header i { font-size: 1.8rem; }
        .checkout-header h3 { font-size: 1.5rem; margin: 0; }
        .payment-methods { display: flex; gap: 15px; padding: 20px 25px 0; justify-content: center; }
        .payment-method { display: flex; align-items: center; gap: 8px; padding: 10px 20px; background: #f8f9fa; border-radius: 50px; cursor: pointer; transition: all 0.3s; border: 2px solid transparent; font-weight: 500; }
        .payment-method.active { border-color: #4facfe; background: #e8f4ff; color: #003366; }
        .card-icons { display: flex; gap: 12px; justify-content: flex-end; padding: 0 25px; margin-bottom: 5px; }
        .card-icons i { font-size: 1.8rem; color: #6c757d; transition: all 0.3s; }
        .card-icons i:hover { color: #003366; transform: translateY(-2px); }
        .checkout-form { padding: 0 25px 25px; }
        .form-group { margin-bottom: 15px; }
        .input-icon { position: relative; }
        .input-icon i { position: absolute; left: 15px; top: 50%; transform: translateY(-50%); color: #4facfe; font-size: 1rem; }
        .input-icon input { width: 100%; padding: 14px 15px 14px 45px; border: 2px solid #e8e8e8; border-radius: 12px; font-size: 0.95rem; transition: all 0.3s; background: #fefefe; }
        .input-icon input:focus { border-color: #4facfe; outline: none; box-shadow: 0 0 0 3px rgba(79,172,254,0.1); }
        .form-row { display: flex; gap: 15px; }
        .form-row .form-group { flex: 1; }
        .checkout-total { background: linear-gradient(135deg, #e8f4ff, #f0f9ff); padding: 18px 25px; border-radius: 15px; margin: 20px 0; text-align: center; }
        .checkout-total strong { font-size: 1.3rem; color: #003366; }
        .checkout-total span { font-size: 1.8rem; font-weight: bold; color: #003366; margin-left: 10px; }
        
        .profile-modal-content { padding: 0; overflow: hidden; max-width: 450px; }
        .profile-header { background: linear-gradient(135deg, #003366, #4facfe); padding: 30px 25px; text-align: center; color: white; }
        .profile-header i { font-size: 4rem; margin-bottom: 15px; display: block; }
        .profile-header h3 { font-size: 1.5rem; margin: 0; }
        .profile-avatar { width: 80px; height: 80px; background: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin: 0 auto 15px; }
        .profile-avatar i { font-size: 3rem; color: #003366; margin: 0; }
        .profile-info { padding: 25px; }
        .info-row { display: flex; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid #f0f0f0; }
        .info-row:last-child { border-bottom: none; }
        .info-label { font-weight: 600; color: #666; }
        .info-value { color: #003366; font-weight: 500; }
        .role-badge { background: #e8f4ff; color: #003366; padding: 4px 12px; border-radius: 20px; font-size: 0.8rem; font-weight: 600; }
        .profile-footer { background: #f8f9fa; padding: 20px; text-align: center; border-top: 1px solid #eee; }
        .profile-footer .btn-close { background: #e8e8e8; color: #666; border: none; padding: 10px 30px; border-radius: 30px; cursor: pointer; font-weight: 600; transition: all 0.3s; }
        .profile-footer .btn-close:hover { background: #003366; color: white; }
        
        .product-detail-container { display: flex; flex-wrap: wrap; }
        .product-detail-image { flex: 1; background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%); border-radius: 25px 0 0 25px; padding: 40px; display: flex; align-items: center; justify-content: center; min-height: 400px; }
        .product-detail-image img { max-width: 100%; max-height: 300px; object-fit: contain; filter: drop-shadow(0 10px 20px rgba(0,0,0,0.1)); }
        .product-detail-info { flex: 1; padding: 40px; background: white; border-radius: 0 25px 25px 0; }
        .product-detail-info h2 { color: #003366; margin-bottom: 15px; font-size: 1.8rem; }
        .detail-price { font-size: 2rem; font-weight: bold; color: #4facfe; margin: 20px 0; }
        .success-icon { text-align: center; font-size: 4rem; color: #28a745; margin-bottom: 20px; }
        
        @media (max-width: 1000px) { .products-grid { grid-template-columns: repeat(2, 1fr); } }
        @media (max-width: 600px) { .products-grid { grid-template-columns: 1fr; } .form-row { flex-direction: column; } .product-detail-image { border-radius: 25px 25px 0 0; } }
    </style>
</head>
<body>
    <header class="dashboard-header">
        <div class="header-container">
            <a href="inicio.html" class="logo"><i class="fas fa-mobile-alt"></i> CellRepair</a>
            <nav class="main-nav">
                <a class="nav-link active" data-page="celulares"><i class="fas fa-mobile-alt"></i> Celulares</a>
                <a class="nav-link" data-page="accesorios"><i class="fas fa-headphones"></i> Accesorios</a>
                <a class="nav-link" data-page="reparaciones"><i class="fas fa-tools"></i> Reparaciones</a>
                <a class="nav-link" data-page="pedidos"><i class="fas fa-shopping-bag"></i> Mis Pedidos</a>
            </nav>
            <div class="header-actions">
                <div class="search-box"><input type="text" id="search-input" placeholder="Buscar..."><i class="fas fa-search"></i></div>
                <a class="cart-icon" id="cart-icon"><i class="fas fa-shopping-cart"></i><span class="cart-count" id="cart-count">0</span></a>
                <div class="user-menu">
                    <a class="user-icon" id="user-icon"><i class="fas fa-user-circle"></i></a>
                    <div class="user-dropdown" id="user-dropdown">
                        <div class="user-info"><strong id="user-name">Usuario</strong><span id="user-role">Cliente</span></div>
                        <hr><a href="#" id="profile-link"><i class="fas fa-user"></i> Mi Perfil</a>
                        <a href="#" id="logout-link"><i class="fas fa-sign-out-alt"></i> Cerrar Sesión</a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <main class="dashboard-main">
        <section id="celulares-section" class="content-section active">
            <h2 class="section-title">Celulares</h2>
            <div class="filters-container">
                <button class="filter-btn active" data-brand="all">Todos</button>
                <button class="filter-btn" data-brand="iphone">iPhone</button>
                <button class="filter-btn" data-brand="samsung">Samsung</button>
                <button class="filter-btn" data-brand="motorola">Motorola</button>
                <button class="filter-btn" data-brand="xiaomi">Xiaomi</button>
            </div>
            <div id="celulares-container" class="products-grid"></div>
        </section>

        <section id="accesorios-section" class="content-section">
            <h2 class="section-title">Accesorios</h2>
            <div class="filters-container">
                <button class="filter-btn active" data-brand="all">Todos</button>
                <button class="filter-btn" data-brand="cargadores">Cargadores</button>
                <button class="filter-btn" data-brand="audifonos">Audífonos</button>
            </div>
            <div id="accesorios-container" class="products-grid"></div>
        </section>

        <section id="reparaciones-section" class="content-section">
            <h2 class="section-title">Reparaciones</h2>
            <div class="repair-hero">
                <div class="repair-hero-content">
                    <h3>Reparación profesional de celulares</h3>
                    <p>Servicio técnico especializado con garantía. Reparamos tu dispositivo con piezas originales y mano de obra calificada.</p>
                    <div class="repair-stats"><div class="stat"><span class="stat-number">+5000</span><span class="stat-label">Reparaciones</span></div><div class="stat"><span class="stat-number">98%</span><span class="stat-label">Satisfacción</span></div><div class="stat"><span class="stat-number">24h</span><span class="stat-label">Tiempo</span></div></div>
                </div>
                <div class="repair-hero-icon"><i class="fas fa-tools"></i></div>
            </div>
            <div class="services-grid" id="services-container"></div>
            <div class="appointment-section">
                <h3>Solicitar Reparación</h3>
                <form id="repair-form" class="repair-form">
                    <div class="form-row"><div class="form-group"><label>Servicio *</label><input type="text" id="servicio-seleccionado" readonly placeholder="Selecciona un servicio"></div>
                    <div class="form-group"><label>Fecha *</label><input type="date" id="cita-fecha" required></div></div>
                    <div class="form-row"><div class="form-group"><label>Hora *</label><select id="cita-hora" required><option value="">Selecciona</option><option value="10:00:00">10:00 AM</option><option value="11:00:00">11:00 AM</option><option value="12:00:00">12:00 PM</option><option value="13:00:00">01:00 PM</option><option value="14:00:00">02:00 PM</option><option value="15:00:00">03:00 PM</option><option value="16:00:00">04:00 PM</option><option value="17:00:00">05:00 PM</option></select></div>
                    <div class="form-group"><label>Teléfono</label><input type="tel" id="cita-telefono" placeholder="5512345678"></div></div>
                    <div class="form-group"><label>Descripción</label><textarea id="cita-descripcion" rows="3"></textarea></div>
                    <button type="submit" class="btn-primary" id="btn-agendar">Agendar Cita</button>
                </form>
                <div class="my-appointments"><h4>Mis Citas</h4><div id="mis-citas-container"></div></div>
            </div>
        </section>

        <section id="pedidos-section" class="content-section">
            <h2 class="section-title"><i class="fas fa-shopping-bag"></i> Mis Pedidos</h2>
            <div class="orders-container" id="orders-container">
                <div class="loading">Cargando tus pedidos...</div>
            </div>
        </section>
    </main>

    <!-- MODALES -->
    <div id="cart-modal" class="modal">
        <div class="modal-content cart-modal-content">
            <span class="close-modal close-cart">&times;</span>
            <div class="cart-header"><i class="fas fa-shopping-cart"></i><h3>Mi Carrito</h3></div>
            <div id="cart-items" class="cart-items-list"></div>
            <div class="cart-footer">
                <div class="cart-total"><span>Total:</span><strong>$<span id="cart-total">0</span></strong></div>
                <button id="checkout-btn" class="btn-primary">Proceder al Pago <i class="fas fa-arrow-right"></i></button>
            </div>
        </div>
    </div>
    
    <div id="checkout-modal" class="modal">
        <div class="modal-content checkout-modal-content">
            <span class="close-modal close-checkout">&times;</span>
            <div class="checkout-header"><i class="fas fa-credit-card"></i><h3>Pago con Tarjeta</h3></div>
            <div class="payment-methods">
                <div class="payment-method active"><i class="fab fa-cc-visa"></i> Visa</div>
                <div class="payment-method"><i class="fab fa-cc-mastercard"></i> Mastercard</div>
                <div class="payment-method"><i class="fab fa-cc-amex"></i> Amex</div>
            </div>
            <div class="card-icons">
                <i class="fab fa-cc-visa"></i>
                <i class="fab fa-cc-mastercard"></i>
                <i class="fab fa-cc-amex"></i>
                <i class="fab fa-cc-paypal"></i>
            </div>
            <form id="checkout-form" class="checkout-form">
                <div class="form-row">
                    <div class="form-group input-icon"><i class="fas fa-user"></i><input type="text" id="nombre" placeholder="Nombre completo" required></div>
                    <div class="form-group input-icon"><i class="fas fa-phone"></i><input type="tel" id="telefono" placeholder="Teléfono"></div>
                </div>
                <div class="form-group input-icon"><i class="fas fa-map-marker-alt"></i><input type="text" id="direccion" placeholder="Dirección de envío" required></div>
                <div class="form-row">
                    <div class="form-group input-icon"><i class="fas fa-mail-bulk"></i><input type="text" id="cp" placeholder="Código Postal"></div>
                </div>
                <div class="form-group input-icon"><i class="fas fa-credit-card"></i><input type="text" id="tarjeta" placeholder="Número de tarjeta" maxlength="19"></div>
                <div class="form-row">
                    <div class="form-group input-icon"><i class="fas fa-calendar-alt"></i><input type="text" id="fecha" placeholder="MM/AA"></div>
                    <div class="form-group input-icon"><i class="fas fa-lock"></i><input type="text" id="cvv" placeholder="CVV" maxlength="4"></div>
                </div>
                <div class="form-group input-icon"><i class="fas fa-signature"></i><input type="text" id="titular" placeholder="Nombre del titular"></div>
                <div class="checkout-total"><strong>Total a pagar: <span id="checkout-total">0</span></strong></div>
                <button type="submit" class="btn-primary">Confirmar Compra <i class="fas fa-check-circle"></i></button>
            </form>
        </div>
    </div>
    
    <div id="profile-modal" class="modal">
        <div class="modal-content profile-modal-content">
            <span class="close-modal close-profile">&times;</span>
            <div class="profile-header">
                <div class="profile-avatar"><i class="fas fa-user-circle"></i></div>
                <h3>Mi Perfil</h3>
            </div>
            <div class="profile-info">
                <div class="info-row"><span class="info-label"><i class="fas fa-user"></i> Usuario</span><span class="info-value" id="profile-username">Cargando...</span></div>
                <div class="info-row"><span class="info-label"><i class="fas fa-tag"></i> Rol</span><span class="info-value" id="profile-role"><span class="role-badge">Cliente</span></span></div>
                <div class="info-row"><span class="info-label"><i class="fas fa-envelope"></i> Correo</span><span class="info-value" id="profile-email">cliente@cellrepair.com</span></div>
                <div class="info-row"><span class="info-label"><i class="fas fa-calendar"></i> Miembro desde</span><span class="info-value" id="profile-since">2024</span></div>
            </div>
            <div class="profile-footer"><button class="btn-close close-profile-btn">Cerrar</button></div>
        </div>
    </div>
    
    <div id="success-modal" class="modal"><div class="modal-content"><span class="close-modal close-success">&times;</span><div class="success-icon"><i class="fas fa-check-circle"></i></div><h3>¡Compra Exitosa!</h3><div id="success-details"></div><button id="close-success-modal" class="btn-primary">Continuar</button></div></div>
    <div id="repair-success-modal" class="modal"><div class="modal-content"><span class="close-modal close-repair-success">&times;</span><div class="success-icon"><i class="fas fa-check-circle"></i></div><h3>¡Cita Agendada!</h3><div id="repair-success-details"></div><button id="close-repair-modal" class="btn-primary">Entendido</button></div></div>
    <div id="product-modal" class="modal"><div class="modal-content large"><span class="close-modal close-product">&times;</span><div class="product-detail-container"><div class="product-detail-image"><img id="detail-img" src="" alt="Producto"></div><div class="product-detail-info"><h2 id="detail-name"></h2><p id="detail-specs"></p><p id="detail-description"></p><div class="detail-price" id="detail-price"></div><button id="detail-add-cart" class="btn-primary">Añadir al carrito</button></div></div></div></div>

    <script>
        // ========== TODOS LOS PRODUCTOS CON SUS IMÁGENES ==========
        const productos = [
            // Celulares iPhone
           { id:1, nombre:"iPhone 17 Pro Max", marca:"iphone", especificaciones:"6.9\" Super Retina XDR • Chip A19 Pro", descripcion:"El iPhone más avanzado...", precio:24999, categoria:"celular", imagen:"Celulares/iPhone17prom.jpg", colores:["Negro Titanio","Blanco Titanio","Azul Titanio"] },

{ id:2, nombre:"iPhone 17", marca:"iphone", especificaciones:"6.1\" Super Retina XDR • Chip A19", descripcion:"iPhone 17...", precio:17999, categoria:"celular", imagen:"Celulares/iPhone17.jpg", colores:["Rosa","Azul","Verde","Negro"] },

{ id:3, nombre:"iPhone 16 Pro Max", marca:"iphone", especificaciones:"6.9\" Super Retina XDR • Chip A18 Pro", descripcion:"Pantalla más grande...", precio:22999, categoria:"celular", imagen:"Celulares/iPhone16promax.jpg", colores:["Negro","Blanco","Titanio Natural"] },

{ id:4, nombre:"iPhone 16", marca:"iphone", especificaciones:"6.1\" Super Retina XDR • Chip A18", descripcion:"iPhone 16...", precio:15999, categoria:"celular", imagen:"Celulares/iPhone16.jpg", colores:["Rosa","Azul","Verde","Negro"] },
            // Celulares Samsung
            { id:5, nombre:"Galaxy S25 Ultra", marca:"samsung", especificaciones:"6.9\" Dynamic AMOLED • 200MP", descripcion:"La mejor cámara del mercado con 200MP, S Pen integrado.", precio:22999, categoria:"celular", imagen:"Celulares/Galaxy S25 Ultra.jpg", colores:["Titanio Negro","Titanio Gris","Titanio Violeta"] },
            { id:6, nombre:"Galaxy S25+", marca:"samsung", especificaciones:"6.7\" Dynamic AMOLED • 50MP", descripcion:"Pantalla de 6.7 pulgadas, cámara de 50MP.", precio:17999, categoria:"celular", imagen:"Celulares/Galaxy S25+.jpg", colores:["Azul","Gris","Verde"] },
            { id:7, nombre:"Galaxy Z Fold 6", marca:"samsung", especificaciones:"7.6\" Plegable • 50MP", descripcion:"El plegable más avanzado con multitarea mejorada.", precio:29999, categoria:"celular", imagen:"Celulares/Galaxy Z Fold 6.jpg", colores:["Negro","Azul","Plata"] },
            { id:8, nombre:"Galaxy Z Flip 6", marca:"samsung", especificaciones:"6.7\" Plegable • 50MP", descripcion:"Diseño compacto, pantalla plegable.", precio:15999, categoria:"celular", imagen:"Celulares/Galaxy Z Flip 6.jpg", colores:["Amarillo","Azul","Verde","Morado"] },
            // Celulares Motorola
            { id:9, nombre:"Edge 50 Ultra", marca:"motorola", especificaciones:"6.7\" OLED 144Hz • 50MP", descripcion:"Pantalla 144Hz, cámara de 50MP.", precio:12999, categoria:"celular", imagen:"Celulares/Edge 50 Ultra.jpg", colores:["Negro","Blanco","Arena"] },
            { id:10, nombre:"Edge 50 Pro", marca:"motorola", especificaciones:"6.7\" pOLED 144Hz • 50MP", descripcion:"Pantalla pOLED 144Hz, carga rápida.", precio:9999, categoria:"celular", imagen:"Celulares/Edge 50 Pro.jpg", colores:["Azul","Negro","Lavanda"] },
            { id:11, nombre:"Razr 50 Ultra", marca:"motorola", especificaciones:"6.9\" Plegable • 50MP", descripcion:"Diseño icónico plegable.", precio:16999, categoria:"celular", imagen:"Celulares/Razr 50 Ultra.jpg", colores:["Negro","Rojo","Azul"] },
            { id:12, nombre:"Moto G85", marca:"motorola", especificaciones:"6.6\" pOLED 120Hz • 50MP", descripcion:"Pantalla pOLED 120Hz, batería de 5000mAh.", precio:5499, categoria:"celular", imagen:"Celulares/Moto G85.jpg", colores:["Gris","Verde","Azul"] },
            // Celulares Xiaomi
            { id:13, nombre:"Xiaomi 15 Ultra", marca:"xiaomi", especificaciones:"6.73\" AMOLED • Leica 50MP", descripcion:"Cámara Leica de 50MP cuádruple.", precio:21999, categoria:"celular", imagen:"Celulares/Xiaomi 15 Ultra.jpg", colores:["Negro","Blanco","Plateado"] },
            { id:14, nombre:"Xiaomi 15 Pro", marca:"xiaomi", especificaciones:"6.73\" AMOLED • Leica 50MP", descripcion:"Cámara Leica, batería de larga duración.", precio:16999, categoria:"celular", imagen:"Celulares/Xiaomi 15 Pro.jpg", colores:["Negro","Blanco","Verde"] },
            { id:15, nombre:"Redmi Note 14 Pro", marca:"xiaomi", especificaciones:"6.67\" AMOLED • 200MP", descripcion:"Cámara de 200MP, carga rápida de 120W.", precio:7999, categoria:"celular", imagen:"Celulares/Redmi Note 14 Pro.jpg", colores:["Negro","Azul","Morado"] },
            { id:16, nombre:"POCO X7 Pro", marca:"xiaomi", especificaciones:"6.67\" AMOLED • 64MP", descripcion:"Rendimiento gaming, batería de 6000mAh.", precio:8999, categoria:"celular", imagen:"Celulares/POCO X7 Pro.jpg", colores:["Negro","Amarillo","Gris"] },
            // Accesorios
            { id:17, nombre:"AirPods Pro 2", marca:"audifonos", especificaciones:"Cancelación activa de ruido", descripcion:"Cancelación de ruido, audio espacial.", precio:3499, categoria:"accesorio", imagen:"Accesorios/Airpods 2 pro.png", colores:["Blanco"] },
            { id:18, nombre:"AirPods 4", marca:"audifonos", especificaciones:"Audio de alta calidad", descripcion:"Audio de alta calidad, diseño ergonómico.", precio:4299, categoria:"accesorio", imagen:"Accesorios/AirPods 4.webp", colores:["Blanco"] },
            { id:19, nombre:"Cargador iPhone 20W", marca:"cargadores", especificaciones:"Carga rápida 20W", descripcion:"Cargador original de Lightning a USB.", precio:399, categoria:"accesorio", imagen:"Accesorios/Cargador iPhone.jpg", colores:["Blanco"] },
            { id:20, nombre:"Cargador USB-C 30W", marca:"cargadores", especificaciones:"Carga ultra rápida 30W", descripcion:"Tecnología GaN, más pequeño.", precio:499, categoria:"accesorio", imagen:"Accesorios/Cargador iPhone  USB-C.jpg", colores:["Blanco","Negro"] },
            { id:21, nombre:"Cable USB-C a USB-C", marca:"cargadores", especificaciones:"Carga rápida • 2 metros", descripcion:"Cable de 2 metros, carga rápida.", precio:199, categoria:"accesorio", imagen:"Accesorios/Cable usb-c a usb-c.jpg", colores:["Blanco","Negro"] },
            { id:22, nombre:"Cable Lightning a USB-C", marca:"cargadores", especificaciones:"Compatible con iPhone", descripcion:"Cable original compatible con iPhone.", precio:199, categoria:"accesorio", imagen:"Accesorios/Cable Lightning a USB-C 1.5m.jpg", colores:["Blanco"] },
            { id:23, nombre:"Audífonos Diadema", marca:"audifonos", especificaciones:"Bluetooth 5.3 • 40h batería", descripcion:"Cancelación de ruido, 40h de batería.", precio:2499, categoria:"accesorio", imagen:"Accesorios/Diadema.jpg", colores:["Negro","Blanco"] },
            { id:24, nombre:"Audífonos EarPods", marca:"audifonos", especificaciones:"Conector 3.5mm", descripcion:"Audífonos con conector de 3.5mm.", precio:599, categoria:"accesorio", imagen:"Accesorios/Earpods.webp", colores:["Blanco"] }
        ];

        let cart = [], filtroCelulares = 'all', filtroAccesorios = 'all', servicioSeleccionado = '', servicioPrecio = 0, userData = null;

        function renderCelulares() {
            let html = '';
            productos.filter(p => p.categoria === 'celular' && (filtroCelulares === 'all' || p.marca === filtroCelulares)).forEach(p => {
                html += `<div class="product-card" data-id="${p.id}" data-nombre="${p.nombre}" data-especificaciones="${p.especificaciones}" data-descripcion="${p.descripcion}" data-precio="${p.precio}" data-imagen="${p.imagen}" data-colores='${JSON.stringify(p.colores)}'>
                    <div class="product-image"><img src="${p.imagen}" onerror="this.src='https://via.placeholder.com/200x200?text=${p.nombre}'"></div>
                    <div class="product-info">
                        <h4 class="product-name">${p.nombre}</h4>
                        <p class="product-specs">${p.especificaciones || ''}</p>
                        <p class="product-price">$${p.precio.toLocaleString()}</p>
                        <button class="btn-add-cart" onclick="addToCart(${p.id}); event.stopPropagation();"><i class="fas fa-shopping-cart"></i></button>
                    </div>
                </div>`;
            });
            document.getElementById('celulares-container').innerHTML = html;
        }

        function renderAccesorios() {
            let html = '';
            productos.filter(p => p.categoria === 'accesorio' && (filtroAccesorios === 'all' || p.marca === filtroAccesorios)).forEach(p => {
                html += `<div class="product-card" data-id="${p.id}" data-nombre="${p.nombre}" data-especificaciones="${p.especificaciones}" data-descripcion="${p.descripcion}" data-precio="${p.precio}" data-imagen="${p.imagen}" data-colores='${JSON.stringify(p.colores)}'>
                    <div class="product-image"><img src="${p.imagen}" onerror="this.src='https://via.placeholder.com/200x200?text=${p.nombre}'"></div>
                    <div class="product-info">
                        <h4 class="product-name">${p.nombre}</h4>
                        <p class="product-specs">${p.especificaciones || ''}</p>
                        <p class="product-price">$${p.precio.toLocaleString()}</p>
                        <button class="btn-add-cart" onclick="addToCart(${p.id}); event.stopPropagation();"><i class="fas fa-shopping-cart"></i></button>
                    </div>
                </div>`;
            });
            document.getElementById('accesorios-container').innerHTML = html;
        }

        // ========== SERVICIOS ACTUALIZADOS CON 10 SERVICIOS ==========
        function renderServicios() {
            const servicios = [
                { nombre: 'Cambio de Pantalla', precio: 1500, id: 1 },
                { nombre: 'Cambio de Batería', precio: 800, id: 2 },
                { nombre: 'Reparación de Cámara', precio: 600, id: 3 },
                { nombre: 'Reparación de Audio', precio: 500, id: 4 },
                { nombre: 'Limpieza por Humedad', precio: 900, id: 5 },
                { nombre: 'Reparación de Puerto Carga', precio: 400, id: 6 },
                { nombre: 'Diagnóstico General', precio: 300, id: 7 },
                { nombre: 'Reparación de Placa', precio: 1200, id: 8 },
                { nombre: 'Cambio de Conector de Carga', precio: 350, id: 9 },
                { nombre: 'Reparación de Botones', precio: 250, id: 10 }
            ];
            
            let html = '';
            servicios.forEach(s => {
                html += `<div class="service-card" data-id="${s.id}" data-precio="${s.precio}" data-nombre="${s.nombre}">
                    <div class="service-icon"><i class="fas fa-tools"></i></div>
                    <h4>${s.nombre}</h4>
                    <div class="service-price">$${s.precio.toLocaleString()}</div>
                    <button class="btn-add-cart" style="margin-top:10px; width:auto; padding:8px 20px; border-radius:30px;">Seleccionar</button>
                </div>`;
            });
            document.getElementById('services-container').innerHTML = html;
            
            // Agregar eventos a las tarjetas de servicio
            document.querySelectorAll('.service-card').forEach(card => {
                card.addEventListener('click', (e) => {
                    if(!e.target.classList.contains('btn-add-cart')) {
                        const nombre = card.dataset.nombre;
                        const precio = parseFloat(card.dataset.precio);
                        const id = parseInt(card.dataset.id);
                        selectService(nombre, precio, id);
                    }
                });
            });
        }

        function selectService(nombre, precio, id) { 
            servicioSeleccionado = nombre; 
            servicioPrecio = precio;
            servicioId = id;
            document.getElementById('servicio-seleccionado').value = `${nombre} - $${precio.toLocaleString()}`; 
            document.querySelectorAll('.service-card').forEach(c => c.classList.remove('selected')); 
            if(event && event.currentTarget) {
                event.currentTarget.classList.add('selected');
            } else {
                const targetCard = Array.from(document.querySelectorAll('.service-card')).find(c => c.dataset.nombre === nombre);
                if(targetCard) targetCard.classList.add('selected');
            }
        }

        function addToCart(id) { 
            const p = productos.find(p => p.id === id); 
            if(p) { 
                cart.push(p); 
                updateCartCount(); 
                updateCartDisplay(); 
                alert(`${p.nombre} agregado al carrito`); 
            } 
        }
        
        function updateCartCount() { 
            document.getElementById('cart-count').textContent = cart.length; 
        }
        
        function updateCartDisplay() { 
            let html = '', total = 0; 
            cart.forEach((item, i) => { 
                total += item.precio; 
                html += `<div class="cart-item">
                    <img src="${item.imagen}" class="cart-item-img" onerror="this.src='https://via.placeholder.com/70x70'">
                    <div class="cart-item-info">
                        <h4>${item.nombre}</h4>
                        <p>${item.especificaciones || ''}</p>
                        <p class="cart-item-price">$${item.precio.toLocaleString()}</p>
                    </div>
                    <button class="cart-item-remove" onclick="removeFromCart(${i})"><i class="fas fa-trash"></i></button>
                </div>`; 
            }); 
            document.getElementById('cart-items').innerHTML = html || `<div class="empty-cart"><i class="fas fa-shopping-cart"></i><p>Tu carrito está vacío</p></div>`; 
            document.getElementById('cart-total').textContent = total.toLocaleString(); 
            document.getElementById('checkout-total').textContent = total.toLocaleString(); 
        }
        
        function removeFromCart(i) { 
            cart.splice(i,1); 
            updateCartCount(); 
            updateCartDisplay(); 
        }

        async function guardarVenta() {
            const items = cart.map(i => ({ Id_producto: i.id, Nombre: i.nombre, Precio: i.precio }));
            const total = cart.reduce((s,p)=>s+p.precio,0);
            const direccion = document.getElementById('direccion').value;
            
            const res = await fetch('api_guardar_venta.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ items, total, direccion: direccion })
            });
            return await res.json();
        }

        // ========== AGENDAR CITA CON ID DE SERVICIO ==========
        async function agendarCita() {
            if(!servicioSeleccionado) { 
                alert('Por favor selecciona un servicio'); 
                return; 
            }
            
            const fecha = document.getElementById('cita-fecha').value;
            const hora = document.getElementById('cita-hora').value;
            
            if(!fecha || !hora) { 
                alert('Selecciona fecha y hora'); 
                return; 
            }
            
            // Mapeo de servicios a IDs (por si no se guardó el ID)
            const servicioMap = {
                'Cambio de Pantalla': 1,
                'Cambio de Batería': 2,
                'Reparación de Cámara': 3,
                'Reparación de Audio': 4,
                'Limpieza por Humedad': 5,
                'Reparación de Puerto Carga': 6,
                'Diagnóstico General': 7,
                'Reparación de Placa': 8,
                'Cambio de Conector de Carga': 9,
                'Reparación de Botones': 10
            };
            
            const id_servicio = servicioMap[servicioSeleccionado] || servicioId;
            
            const data = { 
                id_servicio: id_servicio,
                servicio: servicioSeleccionado,
                precio: servicioPrecio,
                fecha: fecha, 
                hora: hora, 
                telefono: document.getElementById('cita-telefono').value, 
                descripcion: document.getElementById('cita-descripcion').value 
            };
            
            const btn = document.getElementById('btn-agendar');
            const originalText = btn.textContent;
            btn.textContent = 'Agendando...';
            btn.disabled = true;
            
            try {
                const response = await fetch('api_guardar_cita.php', { 
                    method: 'POST', 
                    headers: { 'Content-Type': 'application/json' }, 
                    body: JSON.stringify(data) 
                });
                const result = await response.json();
                
                if(result.success) {
                    alert('✅ Cita agendada correctamente');
                    cargarMisCitas();
                    // Limpiar formulario
                    document.getElementById('servicio-seleccionado').value = '';
                    document.getElementById('cita-fecha').value = '';
                    document.getElementById('cita-hora').value = '';
                    document.getElementById('cita-telefono').value = '';
                    document.getElementById('cita-descripcion').value = '';
                    servicioSeleccionado = '';
                    servicioPrecio = 0;
                    document.querySelectorAll('.service-card').forEach(c => c.classList.remove('selected'));
                } else {
                    alert('❌ Error: ' + (result.message || 'No se pudo agendar la cita'));
                }
            } catch(error) { 
                alert('❌ Error de conexión: ' + error.message); 
            }
            
            btn.textContent = originalText;
            btn.disabled = false;
        }

        async function cargarMisCitas() { 
            try {
                const res = await fetch('api_mis_citas.php'); 
                const citas = await res.json(); 
                let html = ''; 
                if(!citas || citas.length === 0) html = '<p>No tienes citas agendadas</p>'; 
                else citas.forEach(c => { 
                    html += `<div class="appointment-item">
                        <strong>${c.servicio || c.Descripcion || 'Servicio'}</strong>
                        <p>📅 ${c.Fecha} - ${c.Hora?.substring(0,5) || c.hora}</p>
                        <p>📝 ${c.Descripcion || ''}</p>
                        <span style="background:#fff3cd; padding:4px 8px; border-radius:20px;">${c.Estatus || 'Programada'}</span>
                    </div>`; 
                }); 
                document.getElementById('mis-citas-container').innerHTML = html; 
            } catch(e) {
                document.getElementById('mis-citas-container').innerHTML = '<p>Error al cargar citas</p>';
            }
        }

        async function cargarMisPedidos() {
            try {
                const response = await fetch('api_mis_pedidos.php');
                const pedidos = await response.json();
                const container = document.getElementById('orders-container');
                
                if (!pedidos || pedidos.length === 0) {
                    container.innerHTML = `<div class="empty-orders">
                        <i class="fas fa-shopping-bag"></i>
                        <p>No has realizado ninguna compra aún</p>
                        <a href="#" onclick="document.querySelector('[data-page=\'celulares\']').click(); 
                        return false;" class="btn-primary" style="display: inline-block; margin-top: 15px; 
                        text-decoration: none;">Ir a comprar</a>
                    </div>`;
                    return;
                }
                
                let html = '';
                pedidos.forEach(pedido => {
                    html += `
                        <div class="order-card">
                            <div class="order-header">
                                <span class="order-id"><i class="fas fa-receipt"></i> Pedido #${pedido.id}</span>
                                <span class="order-date"><i class="far fa-calendar-alt"></i> ${pedido.fecha}</span>
                                <span class="order-status"><i class="fas fa-check-circle"></i> ${pedido.estatus || 'Completado'}</span>
                            </div>
                            <div class="order-items">
                                ${pedido.items.map(item => `
                                    <div class="order-item">
                                        <span class="order-item-name">${item.nombre}</span>
                                        <span class="order-item-price">$${parseFloat(item.precio).toLocaleString()}</span>
                                    </div>
                                `).join('')}
                            </div>
                            <div class="order-total">
                                <i class="fas fa-dollar-sign"></i> Total: $${parseFloat(pedido.total).toLocaleString()}
                            </div>
                        </div>
                    `;
                });
                container.innerHTML = html;
            } catch(error) {
                console.error('Error:', error);
                document.getElementById('orders-container').innerHTML = `<div class="empty-orders"><i class="fas fa-exclamation-triangle"></i><p>Error al cargar tus pedidos</p></div>`;
            }
        }

        function setupProductDetail() {
            const showDetail = (card) => {
                const nombre = card.dataset.nombre, especificaciones = card.dataset.especificaciones, descripcion = card.dataset.descripcion, precio = card.dataset.precio, imagen = card.dataset.imagen, id = parseInt(card.dataset.id), colores = JSON.parse(card.dataset.colores || '["Sin color"]');
                document.getElementById('detail-img').src = imagen;
                document.getElementById('detail-name').textContent = nombre;
                document.getElementById('detail-specs').textContent = especificaciones;
                document.getElementById('detail-description').textContent = descripcion;
                document.getElementById('detail-price').textContent = `$${parseInt(precio).toLocaleString()}`;
                document.getElementById('detail-add-cart').onclick = () => { addToCart(id); document.getElementById('product-modal').style.display = 'none'; };
                document.getElementById('product-modal').style.display = 'flex';
            };
            document.getElementById('celulares-container').addEventListener('click', (e) => { const card = e.target.closest('.product-card'); if(card && !e.target.classList.contains('btn-add-cart')) showDetail(card); });
            document.getElementById('accesorios-container').addEventListener('click', (e) => { const card = e.target.closest('.product-card'); if(card && !e.target.classList.contains('btn-add-cart')) showDetail(card); });
            document.querySelector('.close-product').onclick = () => document.getElementById('product-modal').style.display = 'none';
        }

        function setupFilters() {
            document.querySelectorAll('#celulares-section .filter-btn').forEach(btn => { btn.onclick = () => { document.querySelectorAll('#celulares-section .filter-btn').forEach(b => b.classList.remove('active')); btn.classList.add('active'); filtroCelulares = btn.dataset.brand; renderCelulares(); }; });
            document.querySelectorAll('#accesorios-section .filter-btn').forEach(btn => { btn.onclick = () => { document.querySelectorAll('#accesorios-section .filter-btn').forEach(b => b.classList.remove('active')); btn.classList.add('active'); filtroAccesorios = btn.dataset.brand; renderAccesorios(); }; });
        }

        function setupSearch() {
            document.getElementById('search-input').addEventListener('input', function() {
                const term = this.value.toLowerCase();
                const cel = productos.filter(p => p.categoria === 'celular' && p.nombre.toLowerCase().includes(term));
                const acc = productos.filter(p => p.categoria === 'accesorio' && p.nombre.toLowerCase().includes(term));
                document.getElementById('celulares-container').innerHTML = cel.map(p => `<div class="product-card" data-id="${p.id}" data-nombre="${p.nombre}" data-especificaciones="${p.especificaciones}" data-descripcion="${p.descripcion}" data-precio="${p.precio}" data-imagen="${p.imagen}"><div class="product-image"><img src="${p.imagen}"></div><div class="product-info"><h4>${p.nombre}</h4><p class="product-price">$${p.precio.toLocaleString()}</p><button class="btn-add-cart" onclick="addToCart(${p.id}); event.stopPropagation();">Añadir</button></div></div>`).join('');
                document.getElementById('accesorios-container').innerHTML = acc.map(p => `<div class="product-card" data-id="${p.id}" data-nombre="${p.nombre}" data-especificaciones="${p.especificaciones}" data-descripcion="${p.descripcion}" data-precio="${p.precio}" data-imagen="${p.imagen}"><div class="product-image"><img src="${p.imagen}"></div><div class="product-info"><h4>${p.nombre}</h4><p class="product-price">$${p.precio.toLocaleString()}</p><button class="btn-add-cart" onclick="addToCart(${p.id}); event.stopPropagation();">Añadir</button></div></div>`).join('');
                if(term === '') { renderCelulares(); renderAccesorios(); }
            });
        }

        function setupNavigation() { 
            document.querySelectorAll('.nav-link').forEach(link => { 
                link.onclick = () => { 
                    document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active')); 
                    link.classList.add('active'); 
                    document.querySelectorAll('.content-section').forEach(s => s.classList.remove('active')); 
                    const page = link.dataset.page;
                    document.getElementById(page + '-section').classList.add('active'); 
                    if(page === 'reparaciones') cargarMisCitas();
                    if(page === 'pedidos') cargarMisPedidos();
                }; 
            }); 
        }

        function setupModals() {
            const cartModal = document.getElementById('cart-modal'), cartIcon = document.getElementById('cart-icon');
            cartIcon.onclick = () => { updateCartDisplay(); cartModal.style.display = 'flex'; };
            document.querySelector('.close-cart').onclick = () => cartModal.style.display = 'none';
            document.getElementById('checkout-btn').onclick = () => { if(cart.length===0) alert('Carrito vacío'); else { cartModal.style.display = 'none'; document.getElementById('checkout-modal').style.display = 'flex'; } };
            document.querySelector('.close-checkout').onclick = () => document.getElementById('checkout-modal').style.display = 'none';
            document.getElementById('checkout-form').onsubmit = async (e) => { e.preventDefault(); const result = await guardarVenta(); if(result.success) { const total = cart.reduce((s,p)=>s+p.precio,0), nombre = document.getElementById('nombre').value, tarjeta = document.getElementById('tarjeta').value.slice(-4); document.getElementById('success-details').innerHTML = `<p><strong>¡Gracias ${nombre}!</strong></p><p>Total: <strong>$${total.toLocaleString()}</strong></p><p>Tarjeta terminación: ****${tarjeta}</p>`; document.getElementById('checkout-modal').style.display = 'none'; document.getElementById('success-modal').style.display = 'flex'; cart = []; updateCartCount(); updateCartDisplay(); cargarMisPedidos(); } else alert('Error: '+result.message); };
            document.querySelector('.close-success').onclick = () => document.getElementById('success-modal').style.display = 'none';
            document.getElementById('close-success-modal').onclick = () => document.getElementById('success-modal').style.display = 'none';
            
            const profileModal = document.getElementById('profile-modal');
            const closeProfile = profileModal.querySelector('.close-profile');
            const closeProfileBtn = profileModal.querySelector('.close-profile-btn');
            closeProfile.onclick = () => profileModal.style.display = 'none';
            if(closeProfileBtn) closeProfileBtn.onclick = () => profileModal.style.display = 'none';
            window.onclick = (e) => { if(e.target === profileModal) profileModal.style.display = 'none'; };
        }

        function loadUser() { 
            fetch('get_user_data.php').then(r=>r.json()).then(data => { 
                if(data.logged_in) { 
                    userData = data; 
                    document.getElementById('user-name').textContent = data.nombre; 
                    document.getElementById('user-role').textContent = data.rol;
                    document.getElementById('profile-username').textContent = data.nombre;
                    document.getElementById('profile-role').innerHTML = `<span class="role-badge">${data.rol === 'admin' ? 'Administrador' : data.rol === 'editor' ? 'Editor' : data.rol === 'consultor' ? 'Consultor' : 'Cliente'}</span>`;
                    if(data.email && data.email !== '') {
                        document.getElementById('profile-email').textContent = data.email;
                    } else {
                        document.getElementById('profile-email').textContent = `${data.nombre}@cellrepair.com`;
                    }
                } else window.location.href = 'index.html'; 
            }).catch(()=>window.location.href='index.html'); 
        }
        
        function setupUserMenu() { 
            const icon = document.getElementById('user-icon'), dropdown = document.getElementById('user-dropdown'); 
            icon.onclick = () => dropdown.classList.toggle('show'); 
           document.getElementById('logout-link').onclick = () => {
    window.location.href = '../logout.php';  // ✅ Esto sube a la raíz
};
            document.getElementById('profile-link').onclick = () => { if(userData) { document.getElementById('profile-username').textContent = userData.nombre; document.getElementById('profile-role').innerHTML = `<span class="role-badge">${userData.rol === 'admin' ? 'Administrador' : userData.rol === 'editor' ? 'Editor' : userData.rol === 'consultor' ? 'Consultor' : 'Cliente'}</span>`; if(userData.email) document.getElementById('profile-email').textContent = userData.email; } document.getElementById('profile-modal').style.display = 'flex'; }; 
        }

        let servicioId = 0;

        document.addEventListener('DOMContentLoaded', () => { 
            renderCelulares(); 
            renderAccesorios(); 
            renderServicios(); 
            setupFilters(); 
            setupSearch(); 
            setupNavigation(); 
            setupModals(); 
            setupProductDetail(); 
            document.getElementById('btn-agendar').onclick = agendarCita; 
            cargarMisCitas(); 
            loadUser(); 
            setupUserMenu(); 
        });
    </script>
</body>
</html>