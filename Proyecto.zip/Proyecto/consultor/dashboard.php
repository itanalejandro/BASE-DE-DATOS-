<?php
session_start();

if (!isset($_SESSION['usuario']) || ($_SESSION['rol'] != 'consultor' && $_SESSION['rol'] != 'editor' && $_SESSION['rol'] != 'admin')) {
    header("Location: ../index.html");
    exit();
}
include '../conexion.php';
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Panel Consultor</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #f0f2f5; }
        .sidebar { position: fixed; left: 0; top: 0; width: 280px; height: 100%; background: linear-gradient(135deg, #1e2a3a, #0f1724); color: white; padding: 30px 20px; overflow-y: auto; }
        .sidebar h2 { font-size: 1.5rem; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 2px solid rgba(255,255,255,0.2); }
        .sidebar h2 i { margin-right: 10px; color: #4facfe; }
        .sidebar .user-info { background: rgba(255,255,255,0.1); padding: 15px; border-radius: 12px; margin-bottom: 30px; text-align: center; }
        .sidebar .user-info i { font-size: 2.5rem; margin-bottom: 10px; color: white; opacity: 0.8; }
        .sidebar .user-info h3 { font-size: 1rem; margin-bottom: 5px; }
        .sidebar .user-info p { font-size: 0.8rem; opacity: 0.7; }
        .sidebar nav ul { list-style: none; }
        .sidebar nav ul li { margin-bottom: 8px; }
        .sidebar nav ul li a { display: flex; align-items: center; gap: 12px; padding: 12px 15px; color: #e0e0e0; text-decoration: none; border-radius: 10px; transition: all 0.3s; }
        .sidebar nav ul li a:hover { background: rgba(79, 172, 254, 0.2); color: white; }
        .sidebar nav ul li a.active { background: #4facfe; color: white; }
        .logout-btn { position: absolute; bottom: 30px; left: 20px; right: 20px; background: rgba(255,255,255,0.1); color: #ff6b6b; padding: 12px; border-radius: 10px; text-decoration: none; display: flex; align-items: center; gap: 12px; transition: all 0.3s; }
        .logout-btn:hover { background: #ff6b6b; color: white; }
        .main-content { margin-left: 280px; padding: 30px; }
        .header { background: white; padding: 20px; border-radius: 20px; margin-bottom: 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.05); }
        .stats-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 25px; margin-bottom: 40px; }
        .stat-card { background: white; padding: 25px; border-radius: 20px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); display: flex; align-items: center; justify-content: space-between; transition: transform 0.3s; }
        .stat-card:hover { transform: translateY(-5px); }
        .stat-info h3 { font-size: 0.85rem; color: #6c757d; margin-bottom: 8px; }
        .stat-info .number { font-size: 2rem; font-weight: 700; color: #1e2a3a; }
        .stat-icon { width: 55px; height: 55px; background: linear-gradient(135deg, #4facfe, #00f2fe); border-radius: 15px; display: flex; align-items: center; justify-content: center; }
        .stat-icon i { font-size: 1.8rem; color: white; }
        .alert-info { background: #cce5ff; color: #004085; padding: 15px; border-radius: 12px; margin-bottom: 30px; display: flex; align-items: center; gap: 10px; }
        .actions-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 15px; margin-top: 20px; }
        .action-btn { display: flex; align-items: center; gap: 12px; padding: 15px 20px; background: #f8f9fa; border-radius: 12px; text-decoration: none; color: #1e2a3a; transition: all 0.3s; border: 1px solid #e9ecef; }
        .action-btn:hover { background: #4facfe; color: white; transform: translateY(-2px); }
        @media (max-width: 1000px) { .sidebar { width: 80px; } .sidebar span { display: none; } .main-content { margin-left: 80px; } .stats-grid { grid-template-columns: 1fr; } }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2><i class="fas fa-mobile-alt"></i> <span>CellRepair</span></h2>
        <div class="user-info"><i class="fas fa-user-circle"></i><h3><?php echo $_SESSION['usuario']; ?></h3><p>Consultor</p></div>
        <nav><ul>
            <li><a href="dashboard.php" class="active"><i class="fas fa-tachometer-alt"></i> <span>Dashboard</span></a></li>
            <li><a href="ver_clientes.php"><i class="fas fa-users"></i> <span>Clientes</span></a></li>
            <li><a href="ver_productos.php"><i class="fas fa-box"></i> <span>Productos</span></a></li>
            <li><a href="ver_citas.php"><i class="fas fa-calendar-alt"></i> <span>Citas</span></a></li>
            <li><a href="ver_ordenes.php"><i class="fas fa-clipboard-list"></i> <span>Órdenes</span></a></li>
            <li><a href="ver_ventas.php"><i class="fas fa-chart-line"></i> <span>Ventas</span></a></li>
            <li><a href="ver_servicios.php"><i class="fas fa-tools"></i> <span>Servicios</span></a></li>
        </ul></nav>
        <a href="../logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> <span>Cerrar sesión</span></a>
    </div>

    <div class="main-content">
        <div class="header">
            <h1><i class="fas fa-search"></i> Panel de Consultor</h1>
            <p>Bienvenido, <?php echo $_SESSION['usuario']; ?></p>
        </div>

        <div class="alert-info">
            <i class="fas fa-info-circle"></i> 
            <strong>Modo consultor:</strong> Solo puedes visualizar información. No tienes permisos para modificar, agregar o eliminar datos.
        </div>

        <?php
        $total_clientes = $conn->query("SELECT COUNT(*) as total FROM Clientes")->fetch_assoc()['total'];
        $total_productos = $conn->query("SELECT COUNT(*) as total FROM Productos")->fetch_assoc()['total'];
        $total_ventas = $conn->query("SELECT COUNT(*) as total FROM Ventas")->fetch_assoc()['total'];
        ?>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-info"><h3>Clientes Registrados</h3><div class="number"><?php echo $total_clientes; ?></div></div>
                <div class="stat-icon"><i class="fas fa-users"></i></div>
            </div>
            <div class="stat-card">
                <div class="stat-info"><h3>Productos Disponibles</h3><div class="number"><?php echo $total_productos; ?></div></div>
                <div class="stat-icon"><i class="fas fa-box"></i></div>
            </div>
            <div class="stat-card">
                <div class="stat-info"><h3>Ventas Realizadas</h3><div class="number"><?php echo $total_ventas; ?></div></div>
                <div class="stat-icon"><i class="fas fa-chart-line"></i></div>
            </div>
        </div>

        <div class="actions-grid">
            <a href="ver_clientes.php" class="action-btn"><i class="fas fa-users"></i> Ver Clientes</a>
            <a href="ver_productos.php" class="action-btn"><i class="fas fa-box"></i> Ver Productos</a>
            <a href="ver_citas.php" class="action-btn"><i class="fas fa-calendar-alt"></i> Ver Citas</a>
            <a href="ver_ordenes.php" class="action-btn"><i class="fas fa-clipboard-list"></i> Ver Órdenes</a>
            <a href="ver_ventas.php" class="action-btn"><i class="fas fa-chart-line"></i> Ver Ventas</a>
            <a href="ver_servicios.php" class="action-btn"><i class="fas fa-tools"></i> Ver Servicios</a>
        </div>
    </div>
</body>
</html>