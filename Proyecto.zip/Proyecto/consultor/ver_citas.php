<?php
session_start();
if (!isset($_SESSION['usuario']) || ($_SESSION['rol'] != 'consultor' && $_SESSION['rol'] != 'editor' && $_SESSION['rol'] != 'admin')) {
    header("Location: ../index.html");
    exit();
}
include '../conexion.php';

$citas = $conn->query("SELECT c.*, cl.Nombre as cliente, s.Descripcion as servicio 
                       FROM Citas c 
                       JOIN Clientes cl ON c.Id_cliente = cl.Id_cliente 
                       JOIN Servicio_reparacion s ON c.Id_servicio = s.Id_servicio 
                       ORDER BY c.Fecha DESC, c.Hora DESC");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Citas - Consultor</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #f0f2f5; }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: 280px;
            height: 100%;
            background: linear-gradient(135deg, #1e2a3a, #0f1724);
            color: white;
            padding: 30px 20px;
            overflow-y: auto;
            z-index: 100;
        }
        .sidebar h2 {
            font-size: 1.5rem;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 2px solid rgba(255,255,255,0.2);
        }
        .sidebar h2 i { margin-right: 10px; color: #4facfe; }
        .sidebar .user-info {
            background: rgba(255,255,255,0.1);
            padding: 15px;
            border-radius: 12px;
            margin-bottom: 30px;
            text-align: center;
        }
        .sidebar .user-info i { font-size: 2.5rem; margin-bottom: 10px; color: white; opacity: 0.8; }
        .sidebar .user-info h3 { font-size: 1rem; margin-bottom: 5px; }
        .sidebar .user-info p { font-size: 0.8rem; opacity: 0.7; }
        .sidebar nav ul { list-style: none; }
        .sidebar nav ul li { margin-bottom: 8px; }
        .sidebar nav ul li a {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 12px 15px;
            color: #e0e0e0;
            text-decoration: none;
            border-radius: 10px;
            transition: all 0.3s;
        }
        .sidebar nav ul li a:hover { background: rgba(79, 172, 254, 0.2); color: white; }
        .sidebar nav ul li a.active { background: #4facfe; color: white; }
        .logout-btn {
            position: absolute;
            bottom: 30px;
            left: 20px;
            right: 20px;
            background: rgba(255,255,255,0.1);
            color: #ff6b6b;
            padding: 12px;
            border-radius: 10px;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: all 0.3s;
        }
        .logout-btn:hover { background: #ff6b6b; color: white; }
        
        /* Main Content */
        .main-content {
            margin-left: 280px;
            padding: 30px;
        }
        .header {
            background: white;
            padding: 20px;
            border-radius: 20px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            display: flex;
            justify-content: space-between;
            align-items: center;
            flex-wrap: wrap;
            gap: 15px;
        }
        .card {
            background: white;
            border-radius: 20px;
            padding: 25px;
            box-shadow: 0 5px 15px rgba(0,0,0,0.05);
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }
        th {
            background: #f8f9fa;
            color: #1e2a3a;
            font-weight: 600;
        }
        tr:hover { background: #f5f5f5; }
        
        /* ✅ CORREGIDO: Clases de estado */
        .estado-programada { background: #fff3cd; color: #856404; padding: 4px 12px; border-radius: 20px; font-size: 0.8rem; display: inline-block; }
        .estado-completada { background: #d4edda; color: #155724; padding: 4px 12px; border-radius: 20px; font-size: 0.8rem; display: inline-block; }
        .estado-cancelada { background: #f8d7da; color: #721c24; padding: 4px 12px; border-radius: 20px; font-size: 0.8rem; display: inline-block; }
        
        .btn-back {
            background: linear-gradient(135deg, #4facfe, #00f2fe);
            color: white;
            padding: 8px 16px;
            text-decoration: none;
            border-radius: 10px;
            display: inline-block;
            transition: all 0.3s;
        }
        .btn-back:hover { transform: translateX(-3px); }
        
        .alert-info {
            background: #cce5ff;
            color: #004085;
            padding: 12px 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        @media (max-width: 1000px) {
            .sidebar { width: 80px; }
            .sidebar span { display: none; }
            .main-content { margin-left: 80px; }
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2><i class="fas fa-mobile-alt"></i> <span>CellRepair</span></h2>
        <div class="user-info">
            <i class="fas fa-user-circle"></i>
            <h3><?php echo $_SESSION['usuario']; ?></h3>
            <p>Consultor</p>
        </div>
        <nav>
            <ul>
                <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> <span>Dashboard</span></a></li>
                <li><a href="ver_clientes.php"><i class="fas fa-users"></i> <span>Clientes</span></a></li>
                <li><a href="ver_productos.php"><i class="fas fa-box"></i> <span>Productos</span></a></li>
                <li><a href="ver_citas.php" class="active"><i class="fas fa-calendar-alt"></i> <span>Citas</span></a></li>
                <li><a href="ver_ordenes.php"><i class="fas fa-clipboard-list"></i> <span>Órdenes</span></a></li>
                <li><a href="ver_ventas.php"><i class="fas fa-chart-line"></i> <span>Ventas</span></a></li>
                <li><a href="ver_servicios.php"><i class="fas fa-tools"></i> <span>Servicios</span></a></li>
            </ul>
        </nav>
        <a href="../logout.php" class="logout-btn"><i class="fas fa-sign-out-alt"></i> <span>Cerrar sesión</span></a>
    </div>

    <div class="main-content">
        <div class="header">
            <h1><i class="fas fa-calendar-alt"></i> Consulta de Citas</h1>
            <a href="dashboard.php" class="btn-back"><i class="fas fa-arrow-left"></i> Volver</a>
        </div>
        
        <div class="alert-info">
            <i class="fas fa-eye"></i> 
            <strong>Modo consultor:</strong> Solo visualización - No puedes modificar datos.
        </div>
        
        <div class="card">
            <div style="overflow-x: auto;">
                <?php if($citas->num_rows == 0): ?>
                    <p style="text-align:center; color:#666; padding: 20px;">
                        <i class="fas fa-calendar-times"></i> No hay citas registradas
                    </p>
                <?php else: ?>
                    <table id="tabla-citas">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Cliente</th>
                                <th>Servicio</th>
                                <th>Fecha</th>
                                <th>Hora</th>
                                <th>Descripción</th>
                                <th>Estado</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while($row = $citas->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $row['Id_cita']; ?></td>
                                <td><?php echo htmlspecialchars($row['cliente']); ?></td>
                                <td><?php echo htmlspecialchars($row['servicio']); ?></td>
                                <td><?php echo $row['Fecha']; ?></td>
                                <td><?php echo substr($row['Hora'], 0, 5); ?></td>
                                <td><?php echo htmlspecialchars($row['Descripcion'] ?: '—'); ?></td>
                                <td>
                                    <?php 
                                    $estado = $row['Estado'];
                                    $icono = '';
                                    if($estado == 'Programada') $icono = '📅 ';
                                    elseif($estado == 'Completada') $icono = '✔️ ';
                                    elseif($estado == 'Cancelada') $icono = '❌ ';
                                    ?>
                                    <span class="estado-<?php echo strtolower($estado); ?>">
                                        <?php echo $icono . $estado; ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>