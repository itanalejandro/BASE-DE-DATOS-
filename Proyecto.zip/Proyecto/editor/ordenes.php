<?php
session_start();
if (!isset($_SESSION['usuario']) || ($_SESSION['rol'] != 'editor' && $_SESSION['rol'] != 'admin')) {
    header("Location: ../index.html");
    exit();
}
include '../conexion.php';

$mensaje = '';
$tipo_mensaje = '';

// Actualizar orden
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id_orden'])) {
    $id_orden = $_POST['id_orden'];
    $estado = $_POST['estado'];
    $costo = !empty($_POST['costo_final']) ? $_POST['costo_final'] : 0;
    
    $sql = "UPDATE Ordenes_reparacion SET Estado = ?, Costo_final = ? WHERE Id_orden = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sdi", $estado, $costo, $id_orden);
    
    if ($stmt->execute()) {
        $mensaje = "✅ Orden #$id_orden actualizada correctamente";
        $tipo_mensaje = "exito";
        echo "<script>setTimeout(function() { window.location='ordenes.php'; }, 2000);</script>";
    } else {
        $mensaje = "❌ Error al actualizar: " . $stmt->error;
        $tipo_mensaje = "error";
    }
}

$ordenes = $conn->query("SELECT o.*, cl.Nombre as cliente, s.Descripcion as servicio 
                         FROM Ordenes_reparacion o 
                         JOIN Clientes cl ON o.Id_cliente = cl.Id_cliente 
                         JOIN Servicio_reparacion s ON o.Id_servicio = s.Id_servicio 
                         ORDER BY o.Id_orden DESC");
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Órdenes - Editor</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Inter', sans-serif; background: #f0f2f5; padding: 30px; }
        .card { background: white; border-radius: 20px; padding: 25px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #e0e0e0; }
        th { background: #f8f9fa; color: #1e2a3a; font-weight: 600; }
        tr:hover { background: #f5f5f5; }
        .btn-back { 
            background: #4facfe; 
            color: white; 
            padding: 10px 20px; 
            text-decoration: none; 
            border-radius: 10px; 
            display: inline-block; 
            margin-bottom: 20px;
            transition: all 0.3s;
        }
        .btn-back:hover { background: #3a8bcf; transform: translateX(-5px); }
        select, input { 
            padding: 8px 12px; 
            border-radius: 8px; 
            border: 1px solid #ddd;
            margin-right: 5px;
            font-size: 0.9rem;
        }
        select:focus, input:focus { outline: none; border-color: #4facfe; }
        .btn-update { 
            background: linear-gradient(135deg, #4facfe, #00f2fe); 
            color: white; 
            border: none; 
            padding: 8px 16px; 
            border-radius: 8px; 
            cursor: pointer;
            font-weight: 500;
            transition: transform 0.2s;
        }
        .btn-update:hover { transform: translateY(-2px); }
        .mensaje {
            padding: 12px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }
        .exito { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        h1 { color: #1e2a3a; margin-bottom: 10px; }
        .estado-pendiente { background: #fff3cd; color: #856404; padding: 4px 8px; border-radius: 20px; font-size: 0.8rem; display: inline-block; }
        .estado-en-proceso { background: #cce5ff; color: #004085; padding: 4px 8px; border-radius: 20px; font-size: 0.8rem; display: inline-block; }
        .estado-completada { background: #d4edda; color: #155724; padding: 4px 8px; border-radius: 20px; font-size: 0.8rem; display: inline-block; }
        @media (max-width: 768px) {
            body { padding: 15px; }
            table { font-size: 0.8rem; }
            .btn-update { padding: 4px 8px; font-size: 0.7rem; }
            select, input { padding: 4px 8px; font-size: 0.7rem; }
        }
    </style>
</head>
<body>
    <a href="dashboard.php" class="btn-back"><i class="fas fa-arrow-left"></i> Volver al Dashboard</a>
    
    <div class="card">
        <h1><i class="fas fa-clipboard-list"></i> Órdenes de Reparación</h1>
        
        <?php if($mensaje): ?>
            <div class="mensaje <?php echo $tipo_mensaje; ?>">
                <i class="fas <?php echo $tipo_mensaje == 'exito' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?>"></i>
                <?php echo $mensaje; ?>
            </div>
        <?php endif; ?>
        
        <div style="overflow-x: auto;">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Cliente</th>
                        <th>Servicio</th>
                        <th>Diagnóstico</th>
                        <th>Estado</th>
                        <th>Costo</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($row = $ordenes->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['Id_orden']; ?></td>
                        <td><?php echo htmlspecialchars($row['cliente']); ?></td>
                        <td><?php echo htmlspecialchars($row['servicio']); ?></td>
                        <td><?php echo htmlspecialchars($row['Diagnostico'] ?: '—'); ?></td>
                        <td>
                            <span class="estado-<?php echo strtolower(str_replace(' ', '-', $row['Estado'])); ?>">
                                <?php echo $row['Estado']; ?>
                            </span>
                        </td>
                        <td>$<?php echo number_format($row['Costo_final'], 2); ?></td>
                        <td>
                            <form method="POST" style="display:inline-flex; gap: 5px; flex-wrap: wrap;">
                                <input type="hidden" name="id_orden" value="<?php echo $row['Id_orden']; ?>">
                                <select name="estado" required>
                                    <option value="Pendiente" <?php echo $row['Estado'] == 'Pendiente' ? 'selected' : ''; ?>>Pendiente</option>
                                    <option value="En proceso" <?php echo $row['Estado'] == 'En proceso' ? 'selected' : ''; ?>>En proceso</option>
                                    <option value="Completada" <?php echo $row['Estado'] == 'Completada' ? 'selected' : ''; ?>>Completada</option>
                                </select>
                                <input type="number" step="0.01" name="costo_final" placeholder="Costo" value="<?php echo $row['Costo_final']; ?>">
                                <button type="submit" class="btn-update"><i class="fas fa-save"></i> Actualizar</button>
                            </form>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>